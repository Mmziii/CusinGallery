"""
Payments models.

Intentionally empty in Phase 1 -- this is a foundation-only app.
Payment gateway abstraction and transaction records.
Business models are implemented in Phase 7 - Payment architecture.

When those models are added here, prefer inheriting from
apps.core.models.TimeStampedModel (and ActivableModel / OrderableModel
where relevant) instead of redefining created_at/updated_at fields.
"""
from django.db import models  # noqa: F401
