"""
Payments API routes, mounted at /api/v1/payments/ (see config/api_urls.py).

Empty in Phase 1 by design -- endpoints are added here in Phase 7 - Payment architecture.
"""
from django.urls import path  # noqa: F401

urlpatterns = []
