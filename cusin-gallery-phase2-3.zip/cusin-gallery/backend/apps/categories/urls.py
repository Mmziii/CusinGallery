"""
Categories API routes, mounted at /api/v1/categories/ (see config/api_urls.py).

Empty in Phase 1 by design -- endpoints are added here in Phase 4 - Products, categories, inventory.
"""
from django.urls import path  # noqa: F401

urlpatterns = []
