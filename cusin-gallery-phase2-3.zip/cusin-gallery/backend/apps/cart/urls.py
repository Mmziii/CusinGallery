"""
Cart API routes, mounted at /api/v1/cart/ (see config/api_urls.py).

Empty in Phase 1 by design -- endpoints are added here in Phase 5 - Cart and wishlist.
"""
from django.urls import path  # noqa: F401

urlpatterns = []
