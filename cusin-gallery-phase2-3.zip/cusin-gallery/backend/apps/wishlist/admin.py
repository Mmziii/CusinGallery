"""
Wishlist admin registration.
"""
from django.contrib import admin

from .models import WishlistItem


@admin.register(WishlistItem)
class WishlistItemAdmin(admin.ModelAdmin):
    list_display = ("user", "product", "created_at")
    search_fields = ("user__username", "user__email", "product__name")
    autocomplete_fields = ("user", "product")
    list_filter = ("created_at",)
