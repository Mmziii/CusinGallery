"""
Accounts API routes, mounted at /api/v1/accounts/ (see config/api_urls.py).

Empty in Phase 1 by design -- endpoints are added here in Phase 3 - Authentication and accounts.
"""
from django.urls import path  # noqa: F401

urlpatterns = []
