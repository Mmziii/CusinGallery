"""
Accounts models.

AUTH_USER_MODEL is set to "accounts.User" from Phase 1 onward (see
config/settings/base.py) -- see that phase's notes for why the model had
to exist before its business fields were ready.

Phase 2 adds:
    - User.phone (plain data field, per the master spec's field list)
    - Address (recipient_name, phone, province, city, address,
      postal_code, unit, building_number, is_default, ...)

Phase 2 deliberately does NOT change how login works. `username` (from
AbstractUser) remains USERNAME_FIELD; the master spec lists `email` as a
User field but doesn't mandate email-based login, and switching
USERNAME_FIELD is an authentication-flow decision (custom manager, login
serializer, uniqueness semantics), not a schema-only change -- that
belongs to Phase 3 - Authentication and accounts, per the instruction not
to implement authentication ahead of its phase. `email` already exists on
User via AbstractUser and is available as a contact field or secondary
lookup regardless of that later decision.
"""
from django.conf import settings
from django.contrib.auth.models import AbstractUser
from django.core.validators import RegexValidator
from django.db import models
from django.db.models import Q

from apps.core.models import TimeStampedModel

phone_validator = RegexValidator(
    regex=r"^\+?\d{7,15}$",
    message="Enter a valid phone number (digits only, optionally prefixed with +).",
)


class User(AbstractUser):
    """Custom user model."""

    phone = models.CharField(
        max_length=20,
        blank=True,
        null=True,
        unique=True,
        validators=[phone_validator],
        help_text="Optional for now; a required/verified phone number is a Phase 3 decision.",
    )

    class Meta:
        verbose_name = "User"
        verbose_name_plural = "Users"


class Address(TimeStampedModel):
    """
    A saved shipping/billing address belonging to a user.

    Deliberately NOT referenced by FK from Order -- orders snapshot their
    shipping address as flat fields at checkout time (see apps.orders),
    so editing or deleting an Address here never rewrites the historical
    record of a past order. This model is only ever the *source* an order
    copies from, never something a placed order points back to.
    """

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="addresses"
    )
    recipient_name = models.CharField(max_length=150)
    phone = models.CharField(max_length=20, validators=[phone_validator])
    province = models.CharField(max_length=100)
    city = models.CharField(max_length=100)
    address = models.TextField()
    postal_code = models.CharField(max_length=20)
    unit = models.CharField(max_length=20, blank=True)
    building_number = models.CharField(max_length=20, blank=True)
    is_default = models.BooleanField(default=False)

    class Meta:
        verbose_name = "Address"
        verbose_name_plural = "Addresses"
        ordering = ["-is_default", "-created_at"]
        indexes = [
            models.Index(fields=["user"], name="addr_user_idx"),
        ]
        constraints = [
            # At most one default address per user, enforced at the
            # database level (a partial unique index) rather than only in
            # application code, which a bulk update or a future bug could
            # bypass.
            models.UniqueConstraint(
                fields=["user"], condition=Q(is_default=True), name="addr_one_default_per_user"
            ),
        ]

    def __str__(self):
        return f"{self.recipient_name} - {self.city}"
