"""
Reviews API routes, mounted at /api/v1/reviews/ (see config/api_urls.py).

Empty in Phase 1 by design -- endpoints are added here in Phase 9 - Admin and content management.
"""
from django.urls import path  # noqa: F401

urlpatterns = []
