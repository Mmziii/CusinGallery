"""
Discounts API routes, mounted at /api/v1/discounts/ (see config/api_urls.py).

Empty in Phase 1 by design -- endpoints are added here in Phase 6 - Checkout and orders.
"""
from django.urls import path  # noqa: F401

urlpatterns = []
