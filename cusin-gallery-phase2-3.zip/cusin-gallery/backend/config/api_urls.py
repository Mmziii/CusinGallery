"""
Aggregates every app's API routes under a single /api/v1/ namespace.

Each include() below points at an app that currently defines an empty
urlpatterns list (see apps/<app>/urls.py). Nothing 404s in a confusing way
during Phase 1 -- these paths simply have no endpoints registered yet, and
each app will fill in its own urls.py as its phase is implemented.
"""
from django.urls import include, path

urlpatterns = [
    path("accounts/", include("apps.accounts.urls")),
    path("products/", include("apps.products.urls")),
    path("categories/", include("apps.categories.urls")),
    path("cart/", include("apps.cart.urls")),
    path("wishlist/", include("apps.wishlist.urls")),
    path("discounts/", include("apps.discounts.urls")),
    path("orders/", include("apps.orders.urls")),
    path("payments/", include("apps.payments.urls")),
    path("reviews/", include("apps.reviews.urls")),
    path("banners/", include("apps.banners.urls")),
]
