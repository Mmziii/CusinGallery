"""
Development settings.

Run with:
    DJANGO_SETTINGS_MODULE=config.settings.development python manage.py runserver

This is also the default manage.py falls back to when DJANGO_SETTINGS_MODULE
is not set at all, so a bare `python manage.py runserver` on a laptop never
accidentally boots with production settings.
"""
from .base import *  # noqa: F401,F403
from .base import env

DEBUG = True

ALLOWED_HOSTS = env.list("ALLOWED_HOSTS", default=["localhost", "127.0.0.1"])

# Permissive CORS locally so the Vite dev server (default: localhost:5173)
# can talk to the API without needing exact origin configuration every time
# a teammate uses a different port. Production is locked down instead --
# see production.py.
CORS_ALLOW_ALL_ORIGINS = True

# Emails are printed to the console instead of actually sent, so no SMTP
# credentials are needed for day-to-day development.
EMAIL_BACKEND = "django.core.mail.backends.console.EmailBackend"

# Django's default DEBUG=True error pages are enough locally; no extra
# security headers are forced on here.
