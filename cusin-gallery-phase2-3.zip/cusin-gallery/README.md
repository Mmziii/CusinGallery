# Cusin Gallery — E-Commerce Platform

Production-oriented e-commerce platform for **Cusin Gallery** (kitchenware,
cookware, glassware, home goods) — Persian-language, targeting the domain
`cusin.ir`.

This repository is being built **phase by phase**. This README documents
**Phase 1: Project Foundation** only.

---

## Tech stack

| Layer      | Technology                                              |
|------------|----------------------------------------------------------|
| Backend    | Python, Django, Django REST Framework, PostgreSQL, Gunicorn |
| Frontend   | React, Vite, React Router, Zustand, Axios                |
| Infra      | Docker, Docker Compose, Nginx, Let's Encrypt (later)      |

---

## Project structure

```
cusin-gallery/
├── backend/
│   ├── manage.py
│   ├── requirements.txt
│   ├── .env.example
│   ├── config/
│   │   ├── settings/
│   │   │   ├── base.py          # shared settings
│   │   │   ├── development.py   # local dev overrides
│   │   │   └── production.py    # production overrides + hardening
│   │   ├── urls.py              # root URLconf (admin/ + api/v1/)
│   │   ├── api_urls.py          # aggregates every app's routes under /api/v1/
│   │   ├── wsgi.py
│   │   └── asgi.py
│   ├── apps/
│   │   ├── core/                # abstract base models only (no table of its own)
│   │   ├── accounts/            # custom User model (minimal for now)
│   │   ├── categories/
│   │   ├── products/
│   │   ├── cart/
│   │   ├── wishlist/
│   │   ├── discounts/
│   │   ├── orders/
│   │   ├── payments/
│   │   ├── reviews/
│   │   └── banners/
│   └── media/                   # uploaded files (gitignored, structure kept)
│
├── frontend/
│   ├── package.json
│   ├── vite.config.js
│   ├── index.html               # lang="fa" dir="rtl"
│   ├── .env.example
│   └── src/
│       ├── main.jsx / App.jsx
│       ├── layouts/MainLayout.jsx
│       ├── pages/                (Home, NotFound — placeholders)
│       ├── services/apiClient.js # single shared axios instance
│       ├── store/useUIStore.js   # UI-only state (cart/auth are server-backed, later)
│       ├── hooks/, utils/
│       └── styles/               # design tokens + RTL-first global CSS
│
├── nginx/
│   ├── nginx.conf
│   └── conf.d/cusin.conf         # public routing for cusin.ir / www.cusin.ir
├── docker/
│   ├── backend/Dockerfile
│   └── frontend/Dockerfile + nginx.conf (internal SPA server)
├── docker-compose.yml
├── .env.example                  # root — used by docker-compose
└── .gitignore
```

---

## What Phase 1 actually contains

- A working Django project with **environment-split settings**
  (`development.py` / `production.py`) instead of one settings file with
  `if DEBUG` branches scattered through it.
- All **11 Django apps created as clean foundations** (`apps.py`, empty
  `models.py` with docstrings explaining what lands there and in which
  phase, empty `admin.py`, empty `urls.py`). No business logic, as agreed.
- **One exception, deliberately**: `apps/accounts/models.py` defines a
  minimal custom `User(AbstractUser)` model, and `AUTH_USER_MODEL` is set
  to it. This could not wait for Phase 3 — Django only allows swapping the
  user model *before* the first migration exists for it; doing it later
  requires a destructive database reset. Committing to a custom user model
  now (even empty) avoids that trap. Its real business fields (`phone`,
  email-based login, `Address` model) are Phase 3 work as planned.
- PostgreSQL-only database configuration (no SQLite anywhere, including
  dev), via `DATABASE_URL` or discrete `POSTGRES_*` variables.
- A React + Vite frontend with routing, layout, a shared Axios client, a
  UI-only Zustand store (explicitly **not** the cart/auth source of
  truth — those are server-backed per the spec and arrive with their
  phases), and an RTL-first, Persian-ready CSS foundation with design
  tokens.
- Full Docker setup: `db`, `backend`, `frontend`, `nginx` services wired
  together, with static/media files served **directly by Nginx**, never
  proxied through Gunicorn.
- An Nginx config for `cusin.ir` / `www.cusin.ir` with HTTPS left as a
  ready-to-uncomment block (no invented certificates), paired with an
  explicit `HTTPS_ENABLED` toggle in Django (see "HTTPS is off by
  default" below) so the default deployment is a genuinely working HTTP
  site rather than a broken redirect-to-nowhere.
- **The initial migration for `accounts.User` is committed**
  (`apps/accounts/migrations/0001_initial.py`). The production workflow
  is `migrate` only — see the "About the committed migrations" note below
  for how it was produced and how to verify it.
- `.env.example` at three levels (root, `backend/`, `frontend/`) — same
  variable names throughout so nothing silently diverges between running
  via Docker and running each half directly.

---

## About the committed migrations

Every model introduced through Phase 2 has its migration committed
(12 migration files across 9 apps as of this phase — see "What Phase 2
built" below for the full list and dependency order), so the normal
workflow from here on is just:
```bash
python manage.py migrate
```
**not** `makemigrations && migrate` — migrations are source code and
belong in version control, not generated on a production server.

One thing to be upfront about: **all of these files were hand-authored**,
not produced by actually running `makemigrations` — the sandbox this
project was built in has no network access, so Django itself could not be
installed to run that command for real (see the "Honesty note" section
below). What's in them was written to match each corresponding
`apps/*/models.py` field-for-field, and cross-checked with automated
(not just eyeballed) comparisons — see "Static checks actually
performed" in "What Phase 2 built" below for exactly what was verified
and how. Before you rely on any of it, verify it matches your installed
Django version:
```bash
python manage.py makemigrations --check --dry-run
```
(no app name = checks every app at once). If that says "No changes
detected", you're good — proceed straight to `migrate`. If it reports a
difference for a specific app, run `makemigrations <app>` for real and
commit whatever it produces in place of the corresponding file here.

From Phase 3 onward, as new fields/models are added, you'll run
`makemigrations <app>` again as normal — that's the ordinary way this
project's migrations grow. Only these first ones needed special
handling, because they couldn't be generated in the environment that
built them.

---

## HTTPS is off by default (and that's intentional)

`config/settings/production.py` has one flag, `HTTPS_ENABLED` (default
`False`), that gates `SECURE_SSL_REDIRECT`, `SESSION_COOKIE_SECURE`,
`CSRF_COOKIE_SECURE`, and HSTS all together.

It defaults to `False` because `nginx/conf.d/cusin.conf` currently only
has an HTTP (port 80) server block — no certificate exists yet. If those
settings defaulted to "on," Django would redirect every request to an
`https://` endpoint Nginx doesn't serve, and would mark cookies
secure-only so browsers silently stop sending them over the plain HTTP
that's actually live — breaking login and CSRF-protected requests
entirely. Deploying Phase 1 as-is over plain HTTP works correctly with
the current defaults.

To go live with HTTPS once you have real certificates:
1. Uncomment the HTTPS `server` block and the HTTP→HTTPS redirect block
   in `nginx/conf.d/cusin.conf`.
2. Set `HTTPS_ENABLED=True` in your `.env`.
3. Uncomment the `"443:443"` port mapping in `docker-compose.yml`.

No other code changes are needed — `SECURE_PROXY_SSL_HEADER` is already
correctly configured for Nginx's proxy headers either way.

---

## Getting started (local, without Docker)

**Backend**
```bash
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env        # then fill in SECRET_KEY at minimum
# Requires a running PostgreSQL matching your .env — see below.
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

You'll need a local PostgreSQL database matching your `.env` first, e.g.:
```bash
createdb cusin_gallery
createuser cusin_user --pwprompt
```

**Frontend**
```bash
cd frontend
npm install
cp .env.example .env
npm run dev
```

> **About `package-lock.json`:** none is committed yet — see "Frontend
> dependency reproducibility" below for why, and please run `npm install`
> once and commit the lockfile it generates. `package.json` currently
> pins exact versions (no `^` ranges) as a weaker interim guarantee.

---

## Getting started (Docker)

```bash
cp .env.example .env        # repo root — fill in SECRET_KEY, POSTGRES_PASSWORD, etc.
docker compose build
docker compose up -d
docker compose exec backend python manage.py migrate
docker compose exec backend python manage.py createsuperuser
```

Then visit `http://localhost/` (frontend) and `http://localhost/admin/`
(Django admin) on your VPS or local machine. HTTPS is not enabled yet —
see "HTTPS is off by default" above for exactly what to change once
you're pointed at the real `cusin.ir` DNS and have real certificates.

---

## What you need to configure manually

- **`SECRET_KEY`** (root `.env` and/or `backend/.env`) — generate with
  `python -c "from django.core.management.utils import get_random_secret_key; print(get_random_secret_key())"`.
  Production refuses to boot without a real one.
- **`POSTGRES_PASSWORD`** — change from the placeholder before deploying.
- **Verify the committed migrations** —
  `python manage.py makemigrations --check --dry-run` (all apps) before
  your first real `migrate`. See "About the committed migrations" above.
- **`frontend/package-lock.json`** — run `npm install` once and commit
  it. See "Frontend dependency reproducibility" below.
- **Real payment gateway credentials** (`PAYMENT_GATEWAY`,
  `PAYMENT_MERCHANT_ID`) — left blank on purpose; you said you'll provide
  these later, and the payment app itself doesn't exist until Phase 7.
- **Email/SMTP credentials** — needed once notifications are built
  (later phase); safe to leave blank for now.
- **Brand assets** — drop the official logo into
  `frontend/src/assets/brand/` and swap the placeholder favicon at
  `frontend/public/favicon.svg`.
- **HTTPS certificates + `HTTPS_ENABLED=True`** — run Certbot against the
  real `cusin.ir` DNS on your actual server, then follow "HTTPS is off by
  default" above. This environment has no way to obtain real
  certificates, so nothing is faked here.
- **DNS** — point `cusin.ir` and `www.cusin.ir` at your VPS.

---

## Frontend dependency reproducibility

No `package-lock.json` is committed in this handoff. That wasn't an
oversight — it's a deliberate choice, and the reasoning matters for how
much to trust it once it does exist:

A real lockfile pins *exact resolved versions and cryptographic integrity
hashes* for every package in the dependency tree, fetched from the npm
registry at install time. Producing one requires actually talking to that
registry. This sandbox has no network access — `npm install` here fails
with a `403` from `registry.npmjs.org` — so there was no way to generate
a real lockfile. Hand-writing one with plausible-looking version numbers
and fabricated hashes would be **worse than having none**: it would look
reproducible while actually being fake, and `npm ci` would either fail
integrity checks against it or (worse) silently "succeed" while proving
nothing.

Instead:
- `package.json` now pins **exact versions** (no `^`/`~` ranges) as a
  weaker but honest interim guarantee.
- `docker/frontend/Dockerfile`'s install step checks for
  `package-lock.json` at build time: if present, it uses `npm ci`
  (the reproducible, production-correct choice); if absent, it falls back
  to `npm install` so the build still works today.

**What to do:** run `npm install` once, anywhere with normal internet
access, and commit the `package-lock.json` it produces. The very next
Docker build will automatically switch to `npm ci` with no further
changes needed.

---

## Honesty note: what could and couldn't be verified here

This was built in a sandboxed environment with **no outbound network
access**, which limited how much could be executed rather than just
reviewed:

- ✅ **Every backend `.py` file compiles** with `python -m py_compile` —
  no syntax errors, across all 88 backend files as of Phase 2 (models,
  admin, and 12 hand-authored migration files across 9 apps).
- ✅ **Migration dependency graph verified programmatically**, not just
  read by eye: parsed with Python's `ast` module and topologically
  sorted with Kahn's algorithm to confirm zero circular dependencies.
- ✅ **Models-vs-migrations cross-checked programmatically**: field
  names, `on_delete` choices, `related_name`s, and named
  constraints/indexes were each diffed between every `models.py` and its
  migration(s) via small AST/regex scripts, not manual read-through
  alone. This caught zero drift issues on this pass, and did catch (and
  I fixed) one real admin bug: `autocomplete_fields` pointing at a model
  with no standalone registered `ModelAdmin`.
- ✅ **`docker-compose.yml` was parsed with PyYAML** — valid YAML, and
  service names/volume mounts were manually cross-checked against
  `nginx/conf.d/cusin.conf` and the Dockerfiles for consistency (upstream
  names, static/media paths, build contexts).
- ✅ **`package.json` was validated as JSON.**
- ✅ **Phase 1 foundation diffed file-by-file against the verified Phase
  1 v2 archive** to confirm nothing outside Phase 2's actual scope
  changed (settings, Docker, Nginx, `apps/core`, `apps/payments` are all
  byte-identical to the approved Phase 1 v2 build).
- ❌ **`npm install` / `vite build` could not be run** — the registry
  request returned `403 Forbidden` in this sandbox (no network egress).
- ❌ **`pip install` / `python manage.py check` / `migrate` /
  `makemigrations --check` could not be run** for the same reason — no
  PyPI access in this sandbox. This is exactly why every migration file
  is flagged as hand-authored rather than machine-generated — see "About
  the committed migrations" above for how to verify them on your side.
  What the checks above *can't* catch: things that are only wrong at
  actual Postgres DDL-execution time (e.g. a subtly invalid constraint
  expression) or a real Django version's exact autogenerated index-name
  hashing. That's precisely why `makemigrations --check --dry-run` is
  the recommended first command, not an optional suggestion.

**What this means for you:** run `pip install -r requirements.txt &&
python manage.py makemigrations --check --dry-run && python manage.py
check` and `npm install && npm run build` as your first steps after
unzipping. If any of these surfaces an issue, it's a real one I couldn't
catch here, and I'd want to fix it before Phase 3 builds on top of it —
flag it and I'll correct it directly rather than working around it.

---

## What Phase 2 built

Phase 2 (Database Architecture & Models) delivered the full relational
schema the rest of the platform builds on — models, Django Admin, and
migrations for every app except `payments` (deliberately still deferred
to Phase 7, see below).

**Models added, by app:**

| App | Models |
|---|---|
| `accounts` | `User.phone` (new field), `Address` |
| `categories` | `Category` (self-referencing tree) |
| `products` | `Brand`, `Product`, `ProductImage`, `ProductAttribute`, `ProductAttributeValue`, `ProductVariant` |
| `cart` | `Cart`, `CartItem` |
| `wishlist` | `WishlistItem` |
| `discounts` | `Coupon`, `CouponUsage` |
| `orders` | `Order`, `OrderItem` |
| `reviews` | `Review` |
| `banners` | `Banner`, `DailyDeal` |
| `payments` | *(none yet — Phase 7)* |

**Dependencies added:** `Pillow==10.4.0` in `backend/requirements.txt`.
Required by Django's `ImageField` at model/system-check time (not just at
actual upload time) — `python manage.py check` fails immediately without
it. Needed as of this phase because four fields are now `ImageField`s:
`categories.Category.image`, `products.Brand.logo`,
`products.ProductImage.image`, `banners.Banner.image`. No other new
dependencies were added — image *upload handling/processing* in the
frontend is still later-phase work; this is only the library Django
itself requires to define these fields at all.

**Design decisions worth knowing about:**
- **Pricing is whole-Toman integers** (`PositiveBigIntegerField`), not
  `DecimalField` — matches the frontend's `formatPrice()` utility from
  Phase 1, which already assumes plain integers.
- **Orders snapshot everything.** `Order`'s shipping address and every
  `OrderItem`'s product name/SKU/price are flat, copied fields — never a
  live FK to `Address` or a live read of `Product.price`. Editing a
  saved address or repricing a product later can never rewrite a past
  order.
- **`discounts` ↔ `orders` circular reference, resolved without a
  circular migration.** `Order.coupon` points at `Coupon`, and
  `CouponUsage.order` points back at `Order`. That's split as
  `discounts.0001` (Coupon) → `orders.0001` (Order) →
  `discounts.0002` (CouponUsage) — a clean line, not a cycle. The
  Python-level circular import this could otherwise cause is avoided
  with Django's lazy `"app_label.Model"` string FK references. This is
  formally verified, not just asserted — see "Static checks actually
  performed" below.
- **`CartItem` uniqueness correctly handles NULL `variant`.** A single
  `UniqueConstraint(fields=["cart", "product", "variant"])` would NOT
  actually prevent duplicate rows for products with no variant —
  Postgres (like SQL generally) treats every `NULL` as distinct from
  every other `NULL`, so a nullable column inside a plain unique
  constraint silently allows unlimited duplicates wherever it's `NULL`.
  This is enforced as two conditional (partial) constraints instead —
  `(cart, product)` unique where `variant IS NULL`, and
  `(cart, product, variant)` unique where `variant IS NOT NULL` — at the
  database level, not just in `clean()`.
- **A few more real database-level constraints**, not just admin-form
  validation: at most one default `Address` per user, at most one
  primary `ProductImage` per product, one `Review` per user per
  product, one `Coupon` redemption tracked per use — all as partial
  unique indexes or unique constraints, enforced even against a bulk
  update or a future bug.
- **No checkout, payment, or full auth logic** — per the phase scope,
  `Order.generate_order_number()` exists only so the model is usable in
  isolation (admin-created orders, seed data); cart→order conversion,
  stock decrement, and payment kickoff are Phase 6/7 work.

**Migration order** (also enforced by Django itself via each file's
`dependencies`):
```
categories.0001 → products.0001 → discounts.0001 (Coupon)
                                 → orders.0001 (needs discounts.0001)
                                 → discounts.0002 (CouponUsage, needs orders.0001)
accounts.0001 → 0002 (phone) → 0003 (Address)
cart.0001, wishlist.0001, reviews.0001, banners.0001 → each depends on products.0001
```

**Static checks actually performed** (see the "Honesty note" section for
what's still unverified without a real Django install):
- Every backend `.py` file compiles (`py_compile`).
- **Migration dependency graph parsed with Python's `ast` module and
  topologically sorted with Kahn's algorithm** — confirms zero circular
  dependencies across all 12 migration files, not just by inspection.
- **Automated field-name diff** between every `models.py` and its
  migration(s) — confirms no model field is missing from its migration.
- **Automated `on_delete` and `related_name` comparison** between models
  and migrations, app by app — all match.
- **Automated `autocomplete_fields` resolution check** across every
  `admin.py` — confirms every field referenced actually points at a
  model with its own registered `ModelAdmin` and `search_fields` (this
  caught and fixed one real bug: `ProductVariant` needed a standalone
  admin registration, not just an inline, for `CartItemInline`'s
  autocomplete to work).
- Named constraints/indexes cross-checked between models and migrations,
  including the two conditional `CartItem` constraints specifically
  (constraint names and `Q()` conditions confirmed equivalent between
  `models.py` and the migration).
- `docker-compose.yml` re-validated as YAML, `package.json` as JSON.
- Diffed against the Phase 1 v2 archive to confirm the foundation
  (settings, Docker, Nginx, `apps/core`, `apps/payments`) is untouched,
  and diffed against the previous Phase 2 archive to confirm this
  correction round touched exactly the 4 files it should have
  (`cart/models.py`, `cart/migrations/0001_initial.py`,
  `requirements.txt`, this README) and nothing else.
- Re-attempted `pip install`/network access before writing this section,
  specifically so this claim wouldn't go stale — still unavailable in
  this sandbox (see "Honesty note" below).

## What Phase 3 will build

Per the original phase plan: **Authentication and accounts** — real
registration/login/logout endpoints and serializers, password reset,
email verification architecture, session/token handling, and the
decision on whether `USERNAME_FIELD` becomes `email`. The schema Phase 3
needs (`User.phone`, `Address`) already exists as of Phase 2.

No further phase will begin until you explicitly ask for it.
