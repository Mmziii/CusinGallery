import axios from "axios";

/**
 * Single axios instance every feature-specific service module (products,
 * cart, orders, ...) should import instead of creating its own client.
 * Centralizing this now means auth-token attachment, CSRF handling, and
 * error normalization only need to be implemented once, in Phase 3/6,
 * instead of being copy-pasted across every service file.
 *
 * VITE_API_BASE_URL must be set at build time (see frontend/.env.example).
 * Falls back to a same-origin relative path so local development works
 * even before .env is configured, matching the Nginx reverse-proxy
 * layout used in production (see nginx/conf.d/cusin.conf).
 */
const apiClient = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || "/api/v1",
  withCredentials: true,
  headers: {
    "Content-Type": "application/json",
  },
});

// Placeholder response interceptor. Real cross-cutting error handling
// (401 -> redirect to login, 429 -> backoff messaging, toast dispatch,
// etc. -- see master spec's error-handling section) is added once those
// flows exist; for now this only normalizes the rejection shape so
// calling code has one consistent thing to catch.
apiClient.interceptors.response.use(
  (response) => response,
  (error) => Promise.reject(error)
);

export default apiClient;
