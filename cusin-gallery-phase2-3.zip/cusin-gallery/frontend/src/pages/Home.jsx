/**
 * Homepage placeholder. Real sections (hero slider, categories, daily
 * deals, featured products, best sellers, banners, ...) are built once
 * their backing API endpoints exist -- see README.md for the phase plan.
 * This page exists now so the routing/build/deploy pipeline is provable
 * end-to-end in Phase 1.
 */
function Home() {
  return (
    <section>
      <h1>کوزین گالری</h1>
      <p>فروشگاه آنلاین به‌زودی راه‌اندازی می‌شود.</p>
    </section>
  );
}

export default Home;
