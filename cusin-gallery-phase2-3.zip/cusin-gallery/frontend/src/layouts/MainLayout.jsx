import { Outlet } from "react-router-dom";

/**
 * Shared page shell. The real header (logo, nav, search, account, wishlist,
 * cart), announcement bar, mobile bottom nav, and footer are all UI-phase
 * work (see README.md) -- this is intentionally a minimal, working
 * placeholder so routing and layout composition are proven out now.
 */
function MainLayout() {
  return (
    <div className="app-shell">
      <header className="app-shell__header">
        <div className="container">
          <span className="app-shell__brand">Cusin Gallery</span>
        </div>
      </header>

      <main className="app-shell__main">
        <div className="container">
          <Outlet />
        </div>
      </main>

      <footer className="app-shell__footer">
        <div className="container">
          <p>© {new Date().getFullYear()} کوزین گالری</p>
        </div>
      </footer>
    </div>
  );
}

export default MainLayout;
