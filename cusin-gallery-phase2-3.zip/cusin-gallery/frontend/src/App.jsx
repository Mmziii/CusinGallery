import { Route, Routes } from "react-router-dom";

import MainLayout from "./layouts/MainLayout.jsx";
import Home from "./pages/Home.jsx";
import NotFound from "./pages/NotFound.jsx";

/**
 * Route skeleton only. Real pages (shop, product detail, cart, checkout,
 * account, ...) are added to this tree in the phases that build them --
 * see README.md for the phase plan. Keeping every route under MainLayout
 * for now; a separate auth-only or checkout-only layout can be introduced
 * later without restructuring this file.
 */
function App() {
  return (
    <Routes>
      <Route element={<MainLayout />}>
        <Route path="/" element={<Home />} />
        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
  );
}

export default App;
