import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    // Allows `npm run dev -- --host` / Docker port mapping to work without
    // Vite refusing connections from outside the container.
    host: true,
  },
  build: {
    outDir: "dist",
    sourcemap: false,
  },
});
