import { useEffect, useState } from "react";

import { getCategoryTree, getProduct, listCategories, listProducts } from "../services/catalogApi";

/**
 * Small, generic "call an async catalog function, track loading/error"
 * hook. Reusable across all the catalog hooks below rather than
 * duplicating the same loading/error/data state machine in each one.
 * Re-runs whenever `deps` changes, same contract as useEffect.
 */
function useAsync(asyncFn, deps) {
  const [state, setState] = useState({ data: null, isLoading: true, error: null });

  useEffect(() => {
    let cancelled = false;
    setState((s) => ({ ...s, isLoading: true, error: null }));

    asyncFn()
      .then((data) => {
        if (!cancelled) setState({ data, isLoading: false, error: null });
      })
      .catch((error) => {
        if (!cancelled) setState({ data: null, isLoading: false, error });
      });

    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);

  return state;
}

/**
 * @param {Object} params - see catalogApi.listProducts
 * @returns {{data: object|null, isLoading: boolean, error: Error|null}}
 *   `data` is the raw paginated response ({count, next, previous, results})
 *   when loaded -- not unwrapped, so callers keep access to pagination
 *   metadata without this hook inventing its own shape for it.
 */
export function useProducts(params = {}) {
  return useAsync(() => listProducts(params), [JSON.stringify(params)]);
}

/**
 * @param {string} slug
 */
export function useProduct(slug) {
  return useAsync(() => getProduct(slug), [slug]);
}

export function useCategories(params = {}) {
  return useAsync(() => listCategories(params), [JSON.stringify(params)]);
}

export function useCategoryTree() {
  return useAsync(() => getCategoryTree(), []);
}
