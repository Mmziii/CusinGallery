# Cusin Gallery — E-Commerce Platform

Production-oriented e-commerce platform for **Cusin Gallery** (kitchenware,
cookware, glassware, home goods) — Persian-language, targeting the domain
`cusin.ir`.

This repository is being built **phase by phase**. This README documents
**Phase 1: Project Foundation** only.

---

## Tech stack

| Layer      | Technology                                              |
|------------|----------------------------------------------------------|
| Backend    | Python, Django, Django REST Framework, PostgreSQL, Gunicorn |
| Frontend   | React, Vite, React Router, Zustand, Axios                |
| Infra      | Docker, Docker Compose, Nginx, Let's Encrypt (later)      |

---

## Project structure

```
cusin-gallery/
├── backend/
│   ├── manage.py
│   ├── requirements.txt
│   ├── .env.example
│   ├── config/
│   │   ├── settings/
│   │   │   ├── base.py          # shared settings
│   │   │   ├── development.py   # local dev overrides
│   │   │   └── production.py    # production overrides + hardening
│   │   ├── urls.py              # root URLconf (admin/ + api/v1/)
│   │   ├── api_urls.py          # aggregates every app's routes under /api/v1/
│   │   ├── wsgi.py
│   │   └── asgi.py
│   ├── apps/
│   │   ├── core/                # abstract base models only (no table of its own)
│   │   ├── accounts/            # custom User model (minimal for now)
│   │   ├── categories/
│   │   ├── products/
│   │   ├── cart/
│   │   ├── wishlist/
│   │   ├── discounts/
│   │   ├── orders/
│   │   ├── payments/
│   │   ├── reviews/
│   │   └── banners/
│   └── media/                   # uploaded files (gitignored, structure kept)
│
├── frontend/
│   ├── package.json
│   ├── vite.config.js
│   ├── index.html               # lang="fa" dir="rtl"
│   ├── .env.example
│   └── src/
│       ├── main.jsx / App.jsx
│       ├── layouts/MainLayout.jsx
│       ├── pages/                (Home, NotFound — placeholders)
│       ├── services/apiClient.js # single shared axios instance
│       ├── store/useUIStore.js   # UI-only state (cart/auth are server-backed, later)
│       ├── hooks/, utils/
│       └── styles/               # design tokens + RTL-first global CSS
│
├── nginx/
│   ├── nginx.conf
│   └── conf.d/cusin.conf         # public routing for cusin.ir / www.cusin.ir
├── docker/
│   ├── backend/Dockerfile
│   └── frontend/Dockerfile + nginx.conf (internal SPA server)
├── docker-compose.yml
├── .env.example                  # root — used by docker-compose
└── .gitignore
```

---

## What Phase 1 actually contains

- A working Django project with **environment-split settings**
  (`development.py` / `production.py`) instead of one settings file with
  `if DEBUG` branches scattered through it.
- All **11 Django apps created as clean foundations** (`apps.py`, empty
  `models.py` with docstrings explaining what lands there and in which
  phase, empty `admin.py`, empty `urls.py`). No business logic, as agreed.
- **One exception, deliberately**: `apps/accounts/models.py` defines a
  minimal custom `User(AbstractUser)` model, and `AUTH_USER_MODEL` is set
  to it. This could not wait for Phase 3 — Django only allows swapping the
  user model *before* the first migration exists for it; doing it later
  requires a destructive database reset. Committing to a custom user model
  now (even empty) avoids that trap. Its real business fields (`phone`,
  email-based login, `Address` model) are Phase 3 work as planned.
- PostgreSQL-only database configuration (no SQLite anywhere, including
  dev), via `DATABASE_URL` or discrete `POSTGRES_*` variables.
- A React + Vite frontend with routing, layout, a shared Axios client, a
  UI-only Zustand store (explicitly **not** the cart/auth source of
  truth — those are server-backed per the spec and arrive with their
  phases), and an RTL-first, Persian-ready CSS foundation with design
  tokens.
- Full Docker setup: `db`, `backend`, `frontend`, `nginx` services wired
  together, with static/media files served **directly by Nginx**, never
  proxied through Gunicorn.
- An Nginx config for `cusin.ir` / `www.cusin.ir` with HTTPS left as a
  ready-to-uncomment block (no invented certificates), paired with an
  explicit `HTTPS_ENABLED` toggle in Django (see "HTTPS is off by
  default" below) so the default deployment is a genuinely working HTTP
  site rather than a broken redirect-to-nowhere.
- **The initial migration for `accounts.User` is committed**
  (`apps/accounts/migrations/0001_initial.py`). The production workflow
  is `migrate` only — see the "About the committed migration" note below
  for how it was produced and how to verify it.
- `.env.example` at three levels (root, `backend/`, `frontend/`) — same
  variable names throughout so nothing silently diverges between running
  via Docker and running each half directly.

---

## About the committed migration

`apps/accounts/migrations/0001_initial.py` is committed, so the normal
workflow from here on is just:
```bash
python manage.py migrate
```
**not** `makemigrations && migrate` — migrations are source code and
belong in version control, not generated on a production server.

One thing to be upfront about: this specific file was **hand-authored**,
not produced by actually running `makemigrations` — the sandbox this
project was built in has no network access, so Django itself could not be
installed to run that command for real (see the "Honesty note" section
below). What's in the file is Django's well-established, unchanged
`AbstractUser` field set for a plain subclass with no extra fields, which
is exactly what `apps/accounts/models.py` currently is. Before you rely
on it, verify it matches your installed Django version:
```bash
python manage.py makemigrations --check --dry-run accounts
```
If that says "No changes detected", you're good — proceed straight to
`migrate`. If it reports a difference, run `makemigrations accounts` for
real and commit whatever it produces in place of this file.

From Phase 3 onward, when `phone`, email-based login, and `Address` are
added to `apps/accounts`, you'll run `makemigrations accounts` again as
normal — that's the ordinary way this project's migrations grow. Only
this first one needed special handling, because it couldn't be generated
in the environment that built it.

---

## HTTPS is off by default (and that's intentional)

`config/settings/production.py` has one flag, `HTTPS_ENABLED` (default
`False`), that gates `SECURE_SSL_REDIRECT`, `SESSION_COOKIE_SECURE`,
`CSRF_COOKIE_SECURE`, and HSTS all together.

It defaults to `False` because `nginx/conf.d/cusin.conf` currently only
has an HTTP (port 80) server block — no certificate exists yet. If those
settings defaulted to "on," Django would redirect every request to an
`https://` endpoint Nginx doesn't serve, and would mark cookies
secure-only so browsers silently stop sending them over the plain HTTP
that's actually live — breaking login and CSRF-protected requests
entirely. Deploying Phase 1 as-is over plain HTTP works correctly with
the current defaults.

To go live with HTTPS once you have real certificates:
1. Uncomment the HTTPS `server` block and the HTTP→HTTPS redirect block
   in `nginx/conf.d/cusin.conf`.
2. Set `HTTPS_ENABLED=True` in your `.env`.
3. Uncomment the `"443:443"` port mapping in `docker-compose.yml`.

No other code changes are needed — `SECURE_PROXY_SSL_HEADER` is already
correctly configured for Nginx's proxy headers either way.

---

## Getting started (local, without Docker)

**Backend**
```bash
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env        # then fill in SECRET_KEY at minimum
# Requires a running PostgreSQL matching your .env — see below.
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

You'll need a local PostgreSQL database matching your `.env` first, e.g.:
```bash
createdb cusin_gallery
createuser cusin_user --pwprompt
```

**Frontend**
```bash
cd frontend
npm install
cp .env.example .env
npm run dev
```

> **About `package-lock.json`:** none is committed yet — see "Frontend
> dependency reproducibility" below for why, and please run `npm install`
> once and commit the lockfile it generates. `package.json` currently
> pins exact versions (no `^` ranges) as a weaker interim guarantee.

---

## Getting started (Docker)

```bash
cp .env.example .env        # repo root — fill in SECRET_KEY, POSTGRES_PASSWORD, etc.
docker compose build
docker compose up -d
docker compose exec backend python manage.py migrate
docker compose exec backend python manage.py createsuperuser
```

Then visit `http://localhost/` (frontend) and `http://localhost/admin/`
(Django admin) on your VPS or local machine. HTTPS is not enabled yet —
see "HTTPS is off by default" above for exactly what to change once
you're pointed at the real `cusin.ir` DNS and have real certificates.

---

## What you need to configure manually

- **`SECRET_KEY`** (root `.env` and/or `backend/.env`) — generate with
  `python -c "from django.core.management.utils import get_random_secret_key; print(get_random_secret_key())"`.
  Production refuses to boot without a real one.
- **`POSTGRES_PASSWORD`** — change from the placeholder before deploying.
- **Verify the committed migration** —
  `python manage.py makemigrations --check --dry-run accounts` before
  your first real `migrate`. See "About the committed migration" above.
- **`frontend/package-lock.json`** — run `npm install` once and commit
  it. See "Frontend dependency reproducibility" below.
- **Real payment gateway credentials** (`PAYMENT_GATEWAY`,
  `PAYMENT_MERCHANT_ID`) — left blank on purpose; you said you'll provide
  these later, and the payment app itself doesn't exist until Phase 7.
- **Email/SMTP credentials** — needed once notifications are built
  (later phase); safe to leave blank for now.
- **Brand assets** — drop the official logo into
  `frontend/src/assets/brand/` and swap the placeholder favicon at
  `frontend/public/favicon.svg`.
- **HTTPS certificates + `HTTPS_ENABLED=True`** — run Certbot against the
  real `cusin.ir` DNS on your actual server, then follow "HTTPS is off by
  default" above. This environment has no way to obtain real
  certificates, so nothing is faked here.
- **DNS** — point `cusin.ir` and `www.cusin.ir` at your VPS.

---

## Frontend dependency reproducibility

No `package-lock.json` is committed in this handoff. That wasn't an
oversight — it's a deliberate choice, and the reasoning matters for how
much to trust it once it does exist:

A real lockfile pins *exact resolved versions and cryptographic integrity
hashes* for every package in the dependency tree, fetched from the npm
registry at install time. Producing one requires actually talking to that
registry. This sandbox has no network access — `npm install` here fails
with a `403` from `registry.npmjs.org` — so there was no way to generate
a real lockfile. Hand-writing one with plausible-looking version numbers
and fabricated hashes would be **worse than having none**: it would look
reproducible while actually being fake, and `npm ci` would either fail
integrity checks against it or (worse) silently "succeed" while proving
nothing.

Instead:
- `package.json` now pins **exact versions** (no `^`/`~` ranges) as a
  weaker but honest interim guarantee.
- `docker/frontend/Dockerfile`'s install step checks for
  `package-lock.json` at build time: if present, it uses `npm ci`
  (the reproducible, production-correct choice); if absent, it falls back
  to `npm install` so the build still works today.

**What to do:** run `npm install` once, anywhere with normal internet
access, and commit the `package-lock.json` it produces. The very next
Docker build will automatically switch to `npm ci` with no further
changes needed.

---

## Honesty note: what could and couldn't be verified here

This was built in a sandboxed environment with **no outbound network
access**, which limited how much could be executed rather than just
reviewed:

- ✅ **Every backend `.py` file compiles** with `python -m py_compile` —
  no syntax errors, including the newly-added `0001_initial.py` migration
  and the revised `production.py`.
- ✅ **`docker-compose.yml` was parsed with PyYAML** — valid YAML, and
  service names/volume mounts were manually cross-checked against
  `nginx/conf.d/cusin.conf` and the Dockerfiles for consistency (upstream
  names, static/media paths, build contexts).
- ✅ **`package.json` was validated as JSON.**
- ❌ **`npm install` / `vite build` could not be run** — the registry
  request returned `403 Forbidden` in this sandbox (no network egress).
  The dependency versions and import paths were reviewed by hand, but the
  actual build has not been executed by me.
- ❌ **`pip install` / `python manage.py check` / `migrate` /
  `makemigrations --check` could not be run** for the same reason — no
  PyPI access in this sandbox. This is exactly why `0001_initial.py` is
  flagged as hand-authored rather than machine-generated — see "About the
  committed migration" above for how to verify it on your side.

**What this means for you:** run `pip install -r requirements.txt &&
python manage.py makemigrations --check --dry-run accounts && python
manage.py check` and `npm install && npm run build` as your first steps
after unzipping. If any of these surfaces an issue, it's a real one I
couldn't catch here, and I'd want to fix it before Phase 2 builds on top
of it — flag it and I'll correct it directly rather than working around it.

---

## What Phase 2 will build

Per the original phase plan (also reflected in the docstrings throughout
`apps/*/models.py`):

- **Phase 2 — Database models and backend**: the core relational
  structure and any shared model infrastructure beyond what `apps/core`
  already provides.
- **Phase 3 — Authentication and accounts**: extends `apps/accounts` with
  `phone`, a decision on email-based login, and the `Address` model.
- **Phase 4 — Products, categories, inventory**: `Category`, `Product`,
  `ProductImage`, variants, stock.

Cart, checkout, and payment logic stay untouched until their own phases
(5–7), per your instruction not to get ahead of the plan.

No further phase will begin until you explicitly ask for it.
