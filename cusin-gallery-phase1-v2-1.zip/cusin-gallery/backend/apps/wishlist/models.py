"""
Wishlist models.

Intentionally empty in Phase 1 -- this is a foundation-only app.
Per-user wishlist of saved products.
Business models are implemented in Phase 5 - Cart and wishlist.

When those models are added here, prefer inheriting from
apps.core.models.TimeStampedModel (and ActivableModel / OrderableModel
where relevant) instead of redefining created_at/updated_at fields.
"""
from django.db import models  # noqa: F401
