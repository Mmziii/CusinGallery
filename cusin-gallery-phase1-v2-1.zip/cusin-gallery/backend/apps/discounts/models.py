"""
Discounts models.

Intentionally empty in Phase 1 -- this is a foundation-only app.
Coupons and discount validation.
Business models are implemented in Phase 6 - Checkout and orders.

When those models are added here, prefer inheriting from
apps.core.models.TimeStampedModel (and ActivableModel / OrderableModel
where relevant) instead of redefining created_at/updated_at fields.
"""
from django.db import models  # noqa: F401
