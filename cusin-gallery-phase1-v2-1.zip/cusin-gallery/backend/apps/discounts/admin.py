"""
Discounts admin registration.

No models exist in this app yet (see models.py) -- registrations are
added here alongside each model in Phase 6 - Checkout and orders.
"""
from django.contrib import admin  # noqa: F401
