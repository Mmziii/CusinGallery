"""
Cart admin registration.

No models exist in this app yet (see models.py) -- registrations are
added here alongside each model in Phase 5 - Cart and wishlist.
"""
from django.contrib import admin  # noqa: F401
