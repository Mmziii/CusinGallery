"""
Products admin registration.

No models exist in this app yet (see models.py) -- registrations are
added here alongside each model in Phase 4 - Products, categories, inventory.
"""
from django.contrib import admin  # noqa: F401
