"""
Products models.

Intentionally empty in Phase 1 -- this is a foundation-only app.
Products, product images, variants, brands.
Business models are implemented in Phase 4 - Products, categories, inventory.

When those models are added here, prefer inheriting from
apps.core.models.TimeStampedModel (and ActivableModel / OrderableModel
where relevant) instead of redefining created_at/updated_at fields.
"""
from django.db import models  # noqa: F401
