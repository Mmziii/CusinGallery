"""
Accounts admin registration.

Registers the Phase 1 minimal User model using Django's built-in
UserAdmin so `createsuperuser` and everyday user management work out of
the box. This registration will be revisited in Phase 3 once phone,
email-based login, and the Address model are added.
"""
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin

from .models import User

admin.site.register(User, UserAdmin)
