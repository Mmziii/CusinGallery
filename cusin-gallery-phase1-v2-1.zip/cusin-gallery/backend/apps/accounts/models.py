"""
Accounts models.

AUTH_USER_MODEL is set to "accounts.User" from Phase 1 onward (see
config/settings/base.py). This is deliberate: Django allows swapping the
user model freely only *before* the first migration exists for it --
after that, changing AUTH_USER_MODEL is destructive and effectively
requires a fresh database. Committing to a custom user model now, even
though its Phase 3 business fields aren't added yet, avoids that trap.

For Phase 1, User adds nothing beyond Django's built-in AbstractUser
(username, email, first_name, last_name, password, is_active, is_staff,
is_superuser, date_joined, last_login). This is foundation-only, not the
business model described in the master spec.

Phase 3 - Authentication and accounts will extend this model with:
    - phone
    - a decision on email-based login (USERNAME_FIELD = "email") per the
      master spec's field list
    - the Address model (recipient_name, phone, province, city, address,
      postal_code, unit, building_number, is_default, ...)

Adding fields to an existing model is a normal, low-risk migration.
Changing AUTH_USER_MODEL after the fact is not -- that asymmetry is why
this file exists in Phase 1 instead of waiting for Phase 3.
"""
from django.contrib.auth.models import AbstractUser


class User(AbstractUser):
    """Custom user model. Deliberately minimal until Phase 3."""

    class Meta:
        verbose_name = "User"
        verbose_name_plural = "Users"
