# Cusin Gallery — E-Commerce Platform

Production-oriented e-commerce platform for **Cusin Gallery** (kitchenware,
cookware, glassware, home goods) — Persian-language, targeting the domain
`cusin.ir`.

This repository is being built **phase by phase**. This README documents
**Phase 1: Project Foundation** only.

---

## Tech stack

| Layer      | Technology                                              |
|------------|----------------------------------------------------------|
| Backend    | Python, Django, Django REST Framework, PostgreSQL, Gunicorn |
| Frontend   | React, Vite, React Router, Zustand, Axios                |
| Infra      | Docker, Docker Compose, Nginx, Let's Encrypt (later)      |

---

## Project structure

```
cusin-gallery/
├── backend/
│   ├── manage.py
│   ├── requirements.txt
│   ├── .env.example
│   ├── config/
│   │   ├── settings/
│   │   │   ├── base.py          # shared settings
│   │   │   ├── development.py   # local dev overrides
│   │   │   └── production.py    # production overrides + hardening
│   │   ├── urls.py              # root URLconf (admin/ + api/v1/)
│   │   ├── api_urls.py          # aggregates every app's routes under /api/v1/
│   │   ├── wsgi.py
│   │   └── asgi.py
│   ├── apps/
│   │   ├── core/                # abstract base models only (no table of its own)
│   │   ├── accounts/            # custom User model (minimal for now)
│   │   ├── categories/
│   │   ├── products/
│   │   ├── cart/
│   │   ├── wishlist/
│   │   ├── discounts/
│   │   ├── orders/
│   │   ├── payments/
│   │   ├── reviews/
│   │   └── banners/
│   └── media/                   # uploaded files (gitignored, structure kept)
│
├── frontend/
│   ├── package.json
│   ├── vite.config.js
│   ├── index.html               # lang="fa" dir="rtl"
│   ├── .env.example
│   └── src/
│       ├── main.jsx / App.jsx
│       ├── layouts/MainLayout.jsx
│       ├── pages/                (Home, NotFound — placeholders)
│       ├── services/apiClient.js # single shared axios instance
│       ├── store/useUIStore.js   # UI-only state (cart/auth are server-backed, later)
│       ├── hooks/, utils/
│       └── styles/               # design tokens + RTL-first global CSS
│
├── nginx/
│   ├── nginx.conf
│   └── conf.d/cusin.conf         # public routing for cusin.ir / www.cusin.ir
├── docker/
│   ├── backend/Dockerfile
│   └── frontend/Dockerfile + nginx.conf (internal SPA server)
├── docker-compose.yml
├── .env.example                  # root — used by docker-compose
└── .gitignore
```

---

## What Phase 1 actually contains

- A working Django project with **environment-split settings**
  (`development.py` / `production.py`) instead of one settings file with
  `if DEBUG` branches scattered through it.
- All **11 Django apps created as clean foundations** (`apps.py`, empty
  `models.py` with docstrings explaining what lands there and in which
  phase, empty `admin.py`, empty `urls.py`). No business logic, as agreed.
- **One exception, deliberately**: `apps/accounts/models.py` defines a
  minimal custom `User(AbstractUser)` model, and `AUTH_USER_MODEL` is set
  to it. This could not wait for Phase 3 — Django only allows swapping the
  user model *before* the first migration exists for it; doing it later
  requires a destructive database reset. Committing to a custom user model
  now (even empty) avoids that trap. Its real business fields (`phone`,
  email-based login, `Address` model) are Phase 3 work as planned.
- PostgreSQL-only database configuration (no SQLite anywhere, including
  dev), via `DATABASE_URL` or discrete `POSTGRES_*` variables.
- A React + Vite frontend with routing, layout, a shared Axios client, a
  UI-only Zustand store (explicitly **not** the cart/auth source of
  truth — those are server-backed per the spec and arrive with their
  phases), and an RTL-first, Persian-ready CSS foundation with design
  tokens.
- Full Docker setup: `db`, `backend`, `frontend`, `nginx` services wired
  together, with static/media files served **directly by Nginx**, never
  proxied through Gunicorn.
- An Nginx config for `cusin.ir` / `www.cusin.ir` with HTTPS left as a
  ready-to-uncomment block (no invented certificates), paired with an
  explicit `HTTPS_ENABLED` toggle in Django (see "HTTPS is off by
  default" below) so the default deployment is a genuinely working HTTP
  site rather than a broken redirect-to-nowhere.
- **The initial migration for `accounts.User` is committed**
  (`apps/accounts/migrations/0001_initial.py`). The production workflow
  is `migrate` only — see the "About the committed migrations" note below
  for how it was produced and how to verify it.
- `.env.example` at three levels (root, `backend/`, `frontend/`) — same
  variable names throughout so nothing silently diverges between running
  via Docker and running each half directly.

---

## About the committed migrations

Every model introduced through Phase 2 has its migration committed
(12 migration files across 9 apps as of this phase — see "What Phase 2
built" below for the full list and dependency order), so the normal
workflow from here on is just:
```bash
python manage.py migrate
```
**not** `makemigrations && migrate` — migrations are source code and
belong in version control, not generated on a production server.

One thing to be upfront about: **all of these files were hand-authored**,
not produced by actually running `makemigrations` — the sandbox this
project was built in has no network access, so Django itself could not be
installed to run that command for real (see the "Honesty note" section
below). What's in them was written to match each corresponding
`apps/*/models.py` field-for-field, and cross-checked with automated
(not just eyeballed) comparisons — see "Static checks actually
performed" in "What Phase 2 built" below for exactly what was verified
and how. Before you rely on any of it, verify it matches your installed
Django version:
```bash
python manage.py makemigrations --check --dry-run
```
(no app name = checks every app at once). If that says "No changes
detected", you're good — proceed straight to `migrate`. If it reports a
difference for a specific app, run `makemigrations <app>` for real and
commit whatever it produces in place of the corresponding file here.

From Phase 3 onward, as new fields/models are added, you'll run
`makemigrations <app>` again as normal — that's the ordinary way this
project's migrations grow. Only these first ones needed special
handling, because they couldn't be generated in the environment that
built them.

---

## HTTPS is off by default (and that's intentional)

`config/settings/production.py` has one flag, `HTTPS_ENABLED` (default
`False`), that gates `SECURE_SSL_REDIRECT`, `SESSION_COOKIE_SECURE`,
`CSRF_COOKIE_SECURE`, and HSTS all together.

It defaults to `False` because `nginx/conf.d/cusin.conf` currently only
has an HTTP (port 80) server block — no certificate exists yet. If those
settings defaulted to "on," Django would redirect every request to an
`https://` endpoint Nginx doesn't serve, and would mark cookies
secure-only so browsers silently stop sending them over the plain HTTP
that's actually live — breaking login and CSRF-protected requests
entirely. Deploying Phase 1 as-is over plain HTTP works correctly with
the current defaults.

To go live with HTTPS once you have real certificates:
1. Uncomment the HTTPS `server` block and the HTTP→HTTPS redirect block
   in `nginx/conf.d/cusin.conf`.
2. Set `HTTPS_ENABLED=True` in your `.env`.
3. Uncomment the `"443:443"` port mapping in `docker-compose.yml`.

No other code changes are needed — `SECURE_PROXY_SSL_HEADER` is already
correctly configured for Nginx's proxy headers either way.

---

## Getting started (local, without Docker)

**Backend**
```bash
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env        # then fill in SECRET_KEY at minimum
# Requires a running PostgreSQL matching your .env — see below.
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

You'll need a local PostgreSQL database matching your `.env` first, e.g.:
```bash
createdb cusin_gallery
createuser cusin_user --pwprompt
```

**Frontend**
```bash
cd frontend
npm install
cp .env.example .env
npm run dev
```

> **About `package-lock.json`:** none is committed yet — see "Frontend
> dependency reproducibility" below for why, and please run `npm install`
> once and commit the lockfile it generates. `package.json` currently
> pins exact versions (no `^` ranges) as a weaker interim guarantee.

---

## Getting started (Docker)

```bash
cp .env.example .env        # repo root — fill in SECRET_KEY, POSTGRES_PASSWORD, etc.
docker compose build
docker compose up -d
docker compose exec backend python manage.py migrate
docker compose exec backend python manage.py createsuperuser
```

Then visit `http://localhost/` (frontend) and `http://localhost/admin/`
(Django admin) on your VPS or local machine. HTTPS is not enabled yet —
see "HTTPS is off by default" above for exactly what to change once
you're pointed at the real `cusin.ir` DNS and have real certificates.

---

## What you need to configure manually

- **`SECRET_KEY`** (root `.env` and/or `backend/.env`) — generate with
  `python -c "from django.core.management.utils import get_random_secret_key; print(get_random_secret_key())"`.
  Production refuses to boot without a real one.
- **`POSTGRES_PASSWORD`** — change from the placeholder before deploying.
- **Verify the committed migrations** —
  `python manage.py makemigrations --check --dry-run` (all apps) before
  your first real `migrate`. See "About the committed migrations" above.
- **`frontend/package-lock.json`** — run `npm install` once and commit
  it. See "Frontend dependency reproducibility" below.
- **Real payment gateway credentials** (`PAYMENT_GATEWAY`,
  `PAYMENT_MERCHANT_ID`) — left blank on purpose; you said you'll provide
  these later, and the payment app itself doesn't exist until Phase 7.
- **Email/SMTP credentials** — now genuinely used as of Phase 3: the
  password-reset flow sends a real email via whatever `EMAIL_BACKEND` is
  configured. In development the console backend already "delivers" it
  (prints to stdout) with no setup needed; in production, set
  `EMAIL_HOST`/`EMAIL_HOST_USER`/`EMAIL_HOST_PASSWORD`/etc. or reset
  emails won't actually send (they'll fail silently — see
  `PasswordResetRequestView`'s `fail_silently=True`, a deliberate choice
  so a misconfigured mail server doesn't turn into a 500 for the user).
- **`FRONTEND_URL`** — defaults to `https://cusin.ir`; only used to
  build the link inside password-reset emails. Change it if your
  frontend is ever served from a different origin than the API.
- **Brand assets** — drop the official logo into
  `frontend/src/assets/brand/` and swap the placeholder favicon at
  `frontend/public/favicon.svg`.
- **HTTPS certificates + `HTTPS_ENABLED=True`** — run Certbot against the
  real `cusin.ir` DNS on your actual server, then follow "HTTPS is off by
  default" above. This environment has no way to obtain real
  certificates, so nothing is faked here.
- **DNS** — point `cusin.ir` and `www.cusin.ir` at your VPS.

---

## Frontend dependency reproducibility

No `package-lock.json` is committed in this handoff. That wasn't an
oversight — it's a deliberate choice, and the reasoning matters for how
much to trust it once it does exist:

A real lockfile pins *exact resolved versions and cryptographic integrity
hashes* for every package in the dependency tree, fetched from the npm
registry at install time. Producing one requires actually talking to that
registry. This sandbox has no network access — `npm install` here fails
with a `403` from `registry.npmjs.org` — so there was no way to generate
a real lockfile. Hand-writing one with plausible-looking version numbers
and fabricated hashes would be **worse than having none**: it would look
reproducible while actually being fake, and `npm ci` would either fail
integrity checks against it or (worse) silently "succeed" while proving
nothing.

Instead:
- `package.json` now pins **exact versions** (no `^`/`~` ranges) as a
  weaker but honest interim guarantee.
- `docker/frontend/Dockerfile`'s install step checks for
  `package-lock.json` at build time: if present, it uses `npm ci`
  (the reproducible, production-correct choice); if absent, it falls back
  to `npm install` so the build still works today.

**What to do:** run `npm install` once, anywhere with normal internet
access, and commit the `package-lock.json` it produces. The very next
Docker build will automatically switch to `npm ci` with no further
changes needed.

---

## Honesty note: what could and couldn't be verified here

This was built in a sandboxed environment with **no outbound network
access**, which limited how much could be executed rather than just
reviewed:

- ✅ **Every backend `.py` file compiles** with `python -m py_compile` —
  99 backend files as of Phase 3 (models, admin, serializers, views,
  permissions, 13 migrations across 9 apps, and 50 test methods).
- ✅ **Migration dependency graph verified programmatically**, not just
  read by eye: parsed with Python's `ast` module and topologically
  sorted with Kahn's algorithm to confirm zero circular dependencies —
  re-run after Phase 3's new `accounts/0004` migration, still clean.
- ✅ **Models-vs-migrations cross-checked programmatically**: field
  names, `on_delete` choices, `related_name`s, and named
  constraints/indexes were each diffed between every `models.py` and its
  migration(s) via small AST/regex scripts, not manual read-through
  alone. This caught zero drift issues in Phase 2's re-check, and did
  catch (and I fixed) one real admin bug in that phase:
  `autocomplete_fields` pointing at a model with no standalone
  registered `ModelAdmin`. Phase 3's `User.email` field/constraint
  change was checked the same way against `0004_user_email_unique.py`.
- ✅ **`docker-compose.yml` was parsed with PyYAML** — valid YAML, and
  service names/volume mounts were manually cross-checked against
  `nginx/conf.d/cusin.conf` and the Dockerfiles for consistency (upstream
  names, static/media paths, build contexts).
- ✅ **`package.json` was validated as JSON.**
- ✅ **Diffed file-by-file against the previous approved archive at each
  phase boundary** — Phase 2 against Phase 1 v2, and this Phase 3 against
  the approved Phase 2 archive — to confirm each phase's changes stayed
  inside its actual scope (Phase 3 touched exactly: `apps/accounts/*`,
  `config/settings/base.py`, `config/api_urls.py`'s docstring,
  `requirements.txt`'s comments, and the three `.env.example` files;
  every other app is untouched).
- ✅ **Phase 3's 50 test methods are real, written code** — reviewed by
  hand for correctness (including catching my own mistake: an initial
  assumption that anonymous access would return 401, corrected to 403
  once I worked through DRF's actual `SessionAuthentication` +
  `handle_exception` behavior — see `tests/test_login_logout.py`'s
  comment) — but **not actually executed**, for the reason below.
- ❌ **`npm install` / `vite build` could not be run** — the registry
  request returned `403 Forbidden` in this sandbox (no network egress).
- ❌ **`pip install` / `python manage.py check` / `migrate` /
  `makemigrations --check` / `python manage.py test` could not be run**
  for the same reason — no PyPI access in this sandbox, re-confirmed
  immediately before finalizing this phase (not just assumed stale from
  earlier). This is exactly why every migration file is flagged as
  hand-authored rather than machine-generated — see "About the committed
  migrations" above for how to verify them on your side.
  What the checks above *can't* catch: things only wrong at actual
  Postgres DDL-execution time, a real Django version's exact
  autogenerated index-name hashing, or — new risk surface as of Phase 3
  — whether the 50 written tests actually pass when run for real. That's
  precisely why `python manage.py test apps.accounts` is listed as a
  first step below, not an optional suggestion.

**What this means for you:** run `pip install -r requirements.txt &&
python manage.py makemigrations --check --dry-run && python manage.py
check && python manage.py test apps.accounts` as your first steps after
unzipping, in addition to `npm install && npm run build` on the
frontend. If any of these surfaces an issue, it's a real one I couldn't
catch here, and I'd want to fix it before Phase 4 builds on top of it —
flag it and I'll correct it directly rather than working around it.
python manage.py makemigrations --check --dry-run && python manage.py
check` and `npm install && npm run build` as your first steps after
unzipping. If any of these surfaces an issue, it's a real one I couldn't
catch here, and I'd want to fix it before Phase 3 builds on top of it —
flag it and I'll correct it directly rather than working around it.

---

## What Phase 2 built

Phase 2 (Database Architecture & Models) delivered the full relational
schema the rest of the platform builds on — models, Django Admin, and
migrations for every app except `payments` (deliberately still deferred
to Phase 7, see below).

**Models added, by app:**

| App | Models |
|---|---|
| `accounts` | `User.phone` (new field), `Address` |
| `categories` | `Category` (self-referencing tree) |
| `products` | `Brand`, `Product`, `ProductImage`, `ProductAttribute`, `ProductAttributeValue`, `ProductVariant` |
| `cart` | `Cart`, `CartItem` |
| `wishlist` | `WishlistItem` |
| `discounts` | `Coupon`, `CouponUsage` |
| `orders` | `Order`, `OrderItem` |
| `reviews` | `Review` |
| `banners` | `Banner`, `DailyDeal` |
| `payments` | *(none yet — Phase 7)* |

**Dependencies added:** `Pillow==10.4.0` in `backend/requirements.txt`.
Required by Django's `ImageField` at model/system-check time (not just at
actual upload time) — `python manage.py check` fails immediately without
it. Needed as of this phase because four fields are now `ImageField`s:
`categories.Category.image`, `products.Brand.logo`,
`products.ProductImage.image`, `banners.Banner.image`. No other new
dependencies were added — image *upload handling/processing* in the
frontend is still later-phase work; this is only the library Django
itself requires to define these fields at all.

**Design decisions worth knowing about:**
- **Pricing is whole-Toman integers** (`PositiveBigIntegerField`), not
  `DecimalField` — matches the frontend's `formatPrice()` utility from
  Phase 1, which already assumes plain integers.
- **Orders snapshot everything.** `Order`'s shipping address and every
  `OrderItem`'s product name/SKU/price are flat, copied fields — never a
  live FK to `Address` or a live read of `Product.price`. Editing a
  saved address or repricing a product later can never rewrite a past
  order.
- **`discounts` ↔ `orders` circular reference, resolved without a
  circular migration.** `Order.coupon` points at `Coupon`, and
  `CouponUsage.order` points back at `Order`. That's split as
  `discounts.0001` (Coupon) → `orders.0001` (Order) →
  `discounts.0002` (CouponUsage) — a clean line, not a cycle. The
  Python-level circular import this could otherwise cause is avoided
  with Django's lazy `"app_label.Model"` string FK references. This is
  formally verified, not just asserted — see "Static checks actually
  performed" below.
- **`CartItem` uniqueness correctly handles NULL `variant`.** A single
  `UniqueConstraint(fields=["cart", "product", "variant"])` would NOT
  actually prevent duplicate rows for products with no variant —
  Postgres (like SQL generally) treats every `NULL` as distinct from
  every other `NULL`, so a nullable column inside a plain unique
  constraint silently allows unlimited duplicates wherever it's `NULL`.
  This is enforced as two conditional (partial) constraints instead —
  `(cart, product)` unique where `variant IS NULL`, and
  `(cart, product, variant)` unique where `variant IS NOT NULL` — at the
  database level, not just in `clean()`.
- **A few more real database-level constraints**, not just admin-form
  validation: at most one default `Address` per user, at most one
  primary `ProductImage` per product, one `Review` per user per
  product, one `Coupon` redemption tracked per use — all as partial
  unique indexes or unique constraints, enforced even against a bulk
  update or a future bug.
- **No checkout, payment, or full auth logic** — per the phase scope,
  `Order.generate_order_number()` exists only so the model is usable in
  isolation (admin-created orders, seed data); cart→order conversion,
  stock decrement, and payment kickoff are Phase 6/7 work.

**Migration order** (also enforced by Django itself via each file's
`dependencies`):
```
categories.0001 → products.0001 → discounts.0001 (Coupon)
                                 → orders.0001 (needs discounts.0001)
                                 → discounts.0002 (CouponUsage, needs orders.0001)
accounts.0001 → 0002 (phone) → 0003 (Address)
cart.0001, wishlist.0001, reviews.0001, banners.0001 → each depends on products.0001
```

**Static checks actually performed** (see the "Honesty note" section for
what's still unverified without a real Django install):
- Every backend `.py` file compiles (`py_compile`).
- **Migration dependency graph parsed with Python's `ast` module and
  topologically sorted with Kahn's algorithm** — confirms zero circular
  dependencies across all 12 migration files, not just by inspection.
- **Automated field-name diff** between every `models.py` and its
  migration(s) — confirms no model field is missing from its migration.
- **Automated `on_delete` and `related_name` comparison** between models
  and migrations, app by app — all match.
- **Automated `autocomplete_fields` resolution check** across every
  `admin.py` — confirms every field referenced actually points at a
  model with its own registered `ModelAdmin` and `search_fields` (this
  caught and fixed one real bug: `ProductVariant` needed a standalone
  admin registration, not just an inline, for `CartItemInline`'s
  autocomplete to work).
- Named constraints/indexes cross-checked between models and migrations,
  including the two conditional `CartItem` constraints specifically
  (constraint names and `Q()` conditions confirmed equivalent between
  `models.py` and the migration).
- `docker-compose.yml` re-validated as YAML, `package.json` as JSON.
- Diffed against the Phase 1 v2 archive to confirm the foundation
  (settings, Docker, Nginx, `apps/core`, `apps/payments`) is untouched,
  and diffed against the previous Phase 2 archive to confirm this
  correction round touched exactly the 4 files it should have
  (`cart/models.py`, `cart/migrations/0001_initial.py`,
  `requirements.txt`, this README) and nothing else.
- Re-attempted `pip install`/network access before writing this section,
  specifically so this claim wouldn't go stale — still unavailable in
  this sandbox (see "Honesty note" below).

## What Phase 3 built

Phase 3 (Authentication and Accounts) delivered a complete, real
authentication and customer-account system on top of Phase 2's `User`
and `Address` models — no new business apps, just `apps.accounts` filled
in, plus the settings changes that decision required.

### Authentication architecture

**Session + CSRF, not JWT/tokens.** Justification (also in
`config/settings/base.py`'s `REST_FRAMEWORK` comment): this project's
own architecture already puts the frontend and API on the same origin —
Nginx serves both `cusin.ir/` and `cusin.ir/api/` from one edge (see
`nginx/conf.d/cusin.conf`). That's exactly the case session auth is the
safer default for: httponly session cookies can't be read by JS at all
(unlike a JWT sitting in localStorage, which XSS can read directly),
Django's session framework is mature and already part of the framework,
and CSRF — session auth's one real extra requirement — was already fully
wired in Phase 1 (`CsrfViewMiddleware`, `CSRF_TRUSTED_ORIGINS`,
`CSRF_COOKIE_SAMESITE`). JWT's usual justification (a genuinely
separate-origin API, or native mobile clients with no cookie jar)
doesn't apply here. `rest_framework.authtoken`, present since Phase 1/2
as an unused placeholder, was removed this phase for the same reason —
an inert second auth backend is exactly the "multiple systems for
completeness" anti-pattern to avoid.

**How login actually works**, since it's a deliberately non-default
path: `USERNAME_FIELD` stays `username` (unchanged from `AbstractUser`)
rather than being switched to `phone`/`email` — actually changing it
would mean overhauling the user manager and re-deriving
uniqueness/authentication semantics from `AbstractBaseUser`, a change
this project has no way to verify end-to-end without a working Django
install (see "Honesty note" below). Instead: registration sets
`username = phone` directly (phone numbers already satisfy Django's
default username character rules), and the login endpoint looks a user
up by phone *or* email manually and checks the password directly,
without going through `authenticate()`/auth backends at all. This
delivers the desired customer-facing behavior (log in with phone or
email) without touching the harder-to-verify machinery. **Django admin
login at `/admin/` is completely unaffected** — it still authenticates
staff by `username`/password through Django's own built-in login view,
entirely separate from these customer-facing endpoints; being staff or
superuser has no special meaning through the API below.

### Endpoints (all under `/api/v1/accounts/`)

| Method | Path | Auth | Purpose |
|---|---|---|---|
| GET | `csrf/` | none | Sets the CSRF cookie; call once on app load before any POST |
| POST | `register/` | none | Create an account (phone required, email optional); auto-logs in |
| POST | `login/` | none | `{identifier, password}` — identifier is phone or email |
| POST | `logout/` | session | Flushes the session server-side |
| GET | `me/` | session | Current user (no `username` in the response — internal detail) |
| PATCH | `me/` | session | Update `first_name`/`last_name`/`email` only — **not** `phone` |
| POST | `me/change-password/` | session | `{current_password, new_password, new_password_confirm}` |
| POST | `password-reset/` | none | `{identifier}` — always returns the same generic response |
| POST | `password-reset/confirm/` | none | `{uid, token, new_password, new_password_confirm}` |
| GET/POST | `addresses/` | session | List / create — scoped to the caller only |
| GET/PATCH/DELETE | `addresses/{id}/` | session | 404s (not 403) for another user's address — see below |
| POST | `addresses/{id}/set-default/` | session | Atomically swaps the default address |

**Why `phone` isn't editable via `PATCH me/`**: changing the phone number
an account logs in with should require re-verification (an SMS OTP
flow), and no SMS provider is configured anywhere in this project. This
is explicitly future-phase work, not something to fake here.

**Why another user's address 404s instead of 403ing**: `AddressViewSet`
scopes its queryset to `request.user`'s own addresses before any
object-level permission check even runs, so another user's address isn't
just forbidden — it doesn't exist from the requester's point of view.
`IsOwner` (in `permissions.py`) is a second, independent layer of the
same guarantee, kept even though the queryset scoping alone is
sufficient, as defense-in-depth against a future `get_queryset()` change.

**A non-obvious status-code detail, in case it looks like a bug**:
requests to a protected endpoint with no session return **403**, not
401. With `SessionAuthentication` as the only registered authenticator
(no `BasicAuthentication`), there's no `WWW-Authenticate` challenge to
offer, so DRF's `handle_exception` downgrades `NotAuthenticated` to
`PermissionDenied` (403) before rendering the response. This is standard
DRF behavior for session-only APIs, asserted and explained in the tests
(`tests/test_login_logout.py`).

### Password reset: real, not faked

The request/confirm flow uses 100% Django built-ins — `PasswordResetTokenGenerator`
for the token, `send_mail()` for delivery — no external service, no
invented credentials. In development, `EMAIL_BACKEND` is the console
backend (Phase 1), so a reset email genuinely prints to the console;
in production it requires real `EMAIL_HOST`/etc, already documented as
manual configuration since Phase 1. **What's explicitly NOT implemented**:
SMS delivery for phone-only accounts. No SMS provider is configured
anywhere in this project, and the master spec says not to hardcode one
— a phone-only account gets the same generic success response as
everyone else, but no message is actually sent (logged instead, so the
gap is visible in server logs rather than silent). Wiring a real SMS
provider is future-phase work.

Every response from `password-reset/` is identical whether or not an
account matches — deliberately, to avoid account enumeration.

### Settings changes this phase required

- `rest_framework.authtoken` removed from `INSTALLED_APPS`;
  `TokenAuthentication` removed from `DEFAULT_AUTHENTICATION_CLASSES`.
- `DEFAULT_THROTTLE_CLASSES`/`DEFAULT_THROTTLE_RATES` added — scoped
  (`ScopedRateThrottle`), not blanket: `register` (10/hour), `login`
  (10/min), `password_reset` (5/hour). Any endpoint that doesn't
  explicitly set `throttle_scope` is completely unaffected.
- `FRONTEND_URL` setting added (new env var, default `https://cusin.ir`)
  — used only to build the link inside password-reset emails.

### Migration (new, not a hand-edit of an applied one)

`apps/accounts/migrations/0004_user_email_unique.py` — makes
`User.email` nullable with a conditional (partial) unique constraint,
mirroring the same NULL-vs-empty-string pattern already used for `phone`
(Phase 2) and `CartItem.variant` (Phase 2 correction round): with email
optional for customers, a plain `unique=True` would incorrectly reject
the *second* customer who simply left email blank, since Postgres treats
two empty strings as duplicates (unlike two `NULL`s). This is a genuinely
new migration, not an edit to `0001`-`0003`, per this phase's own
instruction not to hand-edit an already-applied migration.

### Tests

50 real test methods across `apps/accounts/tests/` (`test_registration.py`,
`test_login_logout.py`, `test_profile.py`, `test_password.py`,
`test_addresses.py`), using `rest_framework.test.APITestCase`. These
assert actual behavior, not just status codes — e.g. that a registered
password is stored hashed (`check_password()` succeeds, raw string
comparison fails), that a session genuinely stops working after logout
(not just that logout returns 200), that setting a second default
address actually flips the first one back via the real Phase 2 database
constraint (not just that the API call succeeds), and that a used
password-reset token is rejected on reuse.

---
