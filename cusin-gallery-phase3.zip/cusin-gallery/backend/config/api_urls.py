"""
Aggregates every app's API routes under a single /api/v1/ namespace.

`accounts/` has real endpoints as of Phase 3 (registration, login,
profile, addresses, ...). Every other include() below still points at an
app whose urls.py currently defines an empty urlpatterns list -- nothing
404s in a confusing way, those paths simply have no endpoints registered
yet, and each app fills in its own urls.py as its phase is implemented.
"""
from django.urls import include, path

urlpatterns = [
    path("accounts/", include("apps.accounts.urls")),
    path("products/", include("apps.products.urls")),
    path("categories/", include("apps.categories.urls")),
    path("cart/", include("apps.cart.urls")),
    path("wishlist/", include("apps.wishlist.urls")),
    path("discounts/", include("apps.discounts.urls")),
    path("orders/", include("apps.orders.urls")),
    path("payments/", include("apps.payments.urls")),
    path("reviews/", include("apps.reviews.urls")),
    path("banners/", include("apps.banners.urls")),
]
